/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Config.Conexion;
import Entidad.*;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ControllerRegistro {
Conexion con = new Conexion();
    JdbcTemplate jdbctemplate = new JdbcTemplate(con.Conectar());
    ModelAndView mav = new ModelAndView();
    
    
        @RequestMapping("registro.htm")
    public ModelAndView Listar(){
        String sql = "Select * from tbregistro";
        List datos=jdbctemplate.queryForList(sql);
        mav.addObject("lista",datos);
        mav.setViewName("listar");
        return mav;
    }
       @RequestMapping(value="registro.htm", method = RequestMethod.GET )
    public ModelAndView Registro(){
        mav.addObject(new Registro());
        mav.setViewName("registro");
        return mav;
    }
@RequestMapping(value="registro.htm", method = RequestMethod.POST )
    public ModelAndView Registro(Registro objEsp){
        String sql = "insert into(user,user_name,clave,correo_id,telefono) tbregistro values(?,?,?,?,?)";
        this.jdbctemplate.update(sql,objEsp.getName(), objEsp.getUse_name(), objEsp.getClave(),objEsp.getCorreo_id(), objEsp.getTelefono());        
        return new ModelAndView("index.htm"); 
        
  
    }
        
    
}
